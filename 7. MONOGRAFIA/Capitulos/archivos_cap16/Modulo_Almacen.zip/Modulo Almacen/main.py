from formularios.maestro_design import MaestroDesign

app = MaestroDesign()

app.mainloop()